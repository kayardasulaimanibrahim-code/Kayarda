export default function Hero() {
  return (
    <section className="p-10 text-center text-4xl font-bold">
      Innovating the future. Today.
    </section>
  );
}