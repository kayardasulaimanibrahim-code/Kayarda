export default function Footer() {
  return (
    <footer className="p-6 text-center opacity-70">
      © 2025 KAYARDA Enterprises
    </footer>
  );
}