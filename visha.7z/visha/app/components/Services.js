export default function Services() {
  return (
    <section className="p-10 text-xl">
      <p>Services section placeholder</p>
    </section>
  );
}