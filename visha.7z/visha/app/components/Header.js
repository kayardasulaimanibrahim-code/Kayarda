export default function Header() {
  return (
    <header className="p-6 font-bold text-2xl">
      KAYARDA Enterprises
    </header>
  );
}