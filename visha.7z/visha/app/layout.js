export const metadata = {
  title: "KAYARDA Enterprises",
  description: "Enterprise-grade tech innovation",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-white text-black dark:bg-gray-900 dark:text-white transition-colors">
        {children}
      </body>
    </html>
  );
}